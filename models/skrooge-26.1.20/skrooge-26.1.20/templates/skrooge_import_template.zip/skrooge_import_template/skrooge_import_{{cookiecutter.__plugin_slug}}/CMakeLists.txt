#***************************************************************************
#* SPDX-FileCopyrightText: 2023 {{cookiecutter.author}} {{cookiecutter.email}}
#*  SPDX-License-Identifier: GPL-3.0-or-later
#***************************************************************************
MESSAGE( STATUS "..:: CMAKE PLUGIN_IMPORT_{{cookiecutter.plugin_name | upper}} ::..")

PROJECT(plugin_import_{{cookiecutter.__plugin_slug}})

LINK_DIRECTORIES (${LIBRARY_OUTPUT_PATH})

SET(skrooge_import_{{cookiecutter.__plugin_slug}}_SRCS
	skgimportplugin{{cookiecutter.__plugin_slug}}.cpp
)

ADD_LIBRARY(skrooge_import_{{cookiecutter.__plugin_slug}} MODULE ${skrooge_import_{{cookiecutter.__plugin_slug}}_SRCS})
TARGET_LINK_LIBRARIES(skrooge_import_{{cookiecutter.__plugin_slug}} KF5::Parts skgbasemodeler skgbasegui skgbankmodeler skgbankgui)

########### install files ###############
INSTALL(TARGETS skrooge_import_{{cookiecutter.__plugin_slug}} DESTINATION ${KDE_INSTALL_QTPLUGINDIR})
INSTALL(FILES ${PROJECT_SOURCE_DIR}/org.kde.skrooge-import-{{cookiecutter.__plugin_slug}}.desktop DESTINATION ${KDE_INSTALL_KSERVICES5DIR})

