#***************************************************************************
#* SPDX-FileCopyrightText: 2023 {{cookiecutter.author}} {{cookiecutter.email}}
#* SPDX-License-Identifier: GPL-3.0-or-later
#***************************************************************************
MESSAGE( STATUS "..:: CMAKE PLUGIN_{{cookiecutter.__plugin_slug}} ::..")

PROJECT(plugin_{{cookiecutter.__plugin_slug}})

LINK_DIRECTORIES (${LIBRARY_OUTPUT_PATH})

SET(skrooge_{{cookiecutter.__plugin_slug}}_SRCS
	skg{{cookiecutter.__plugin_slug}}plugin.cpp
	skg{{cookiecutter.__plugin_slug}}pluginwidget.cpp)

ki18n_wrap_ui(skrooge_{{cookiecutter.__plugin_slug}}_SRCS skg{{cookiecutter.__plugin_slug}}pluginwidget_base.ui skg{{cookiecutter.__plugin_slug}}pluginwidget_pref.ui)
kconfig_add_kcfg_files(skrooge_{{cookiecutter.__plugin_slug}}_SRCS skg{{cookiecutter.__plugin_slug}}_settings.kcfgc )

ADD_LIBRARY(skrooge_{{cookiecutter.__plugin_slug}} MODULE ${skrooge_{{cookiecutter.__plugin_slug}}_SRCS})
TARGET_LINK_LIBRARIES(skrooge_{{cookiecutter.__plugin_slug}} KF5::Parts skgbasemodeler skgbasegui)

########### install files ###############
INSTALL(TARGETS skrooge_{{cookiecutter.__plugin_slug}} DESTINATION ${KDE_INSTALL_QTPLUGINDIR})
INSTALL(FILES ${PROJECT_SOURCE_DIR}/org.kde.skrooge-plugin-{{cookiecutter.__plugin_slug}}.desktop DESTINATION ${KDE_INSTALL_KSERVICES5DIR})
INSTALL(FILES ${PROJECT_SOURCE_DIR}/skrooge_{{cookiecutter.__plugin_slug}}.rc  DESTINATION  ${KDE_INSTALL_KXMLGUI5DIR}/skrooge_{{cookiecutter.__plugin_slug}} )
INSTALL(FILES ${PROJECT_SOURCE_DIR}/skg{{cookiecutter.__plugin_slug}}_settings.kcfg  DESTINATION  ${KDE_INSTALL_KCFGDIR} )

ECM_INSTALL_ICONS(${KDE_INSTALL_ICONDIR})
