/***************************************************************************
 * SPDX-FileCopyrightText: 2023 {{cookiecutter.author}} {{cookiecutter.email}}
 * SPDX-License-Identifier: GPL-3.0-or-later
 ***************************************************************************/
#ifndef SKG{{cookiecutter.__plugin_slug | upper}}PLUGINWIDGET_H
#define SKG{{cookiecutter.__plugin_slug | upper}}PLUGINWIDGET_H
/** @file
 * {{cookiecutter.description}}
*
* @author {{cookiecutter.email}}
*/
#include "ui_skg{{cookiecutter.__plugin_slug}}pluginwidget_base.h"
#include "skgtabpage.h"

/**
 * {{cookiecutter.description}}
 */
class SKG{{cookiecutter.__plugin_slug}}PluginWidget : public SKGTabPage
{
    Q_OBJECT

public:
    /**
     * Default Constructor
     * @param iParent the parent widget
     * @param iDocument the document
     */
    explicit SKG{{cookiecutter.__plugin_slug}}PluginWidget(QWidget* iParent, SKGDocument* iDocument);

    /**
     * Default Destructor
     */
    virtual ~SKG{{cookiecutter.__plugin_slug}}PluginWidget();

    /**
     * Get the current state
     * MUST BE OVERWRITTEN
     * @return a string containing all information needed to set the same state.
     * Could be an XML stream
     */
    virtual QString getState() override;

    /**
     * Set the current state
     * MUST BE OVERWRITTEN
     * @param iState must be interpreted to set the state of the widget
     */
    virtual void setState(const QString& iState) override;

    /**
     * Get attribute name to save the default state
     * MUST BE OVERWRITTEN
     * @return attribute name to save the default state.
     */
    virtual QString getDefaultStateAttribute() override;

    /**
     * Get the main widget
     * @return a widget
     */
    virtual QWidget* mainWidget() override;

public Q_SLOTS:
    /**
    * Refresh the content.
     */
    virtual void refresh();

private Q_SLOTS:


private:
    Q_DISABLE_COPY(SKG{{cookiecutter.__plugin_slug}}PluginWidget)

    Ui::skg{{cookiecutter.__plugin_slug}}plugin_base ui;
};

#endif  // SKG{{cookiecutter.__plugin_slug | upper}}PLUGINWIDGET_H
