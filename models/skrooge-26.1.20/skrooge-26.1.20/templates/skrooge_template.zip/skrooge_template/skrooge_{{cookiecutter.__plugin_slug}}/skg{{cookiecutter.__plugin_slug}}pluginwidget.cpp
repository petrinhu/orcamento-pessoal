/***************************************************************************
 * SPDX-FileCopyrightText: 2023 {{cookiecutter.author}} {{cookiecutter.email}}
 * SPDX-License-Identifier: GPL-3.0-or-later
 ***************************************************************************/
/** @file
 * {{cookiecutter.description}}.
 *
 * @author {{cookiecutter.author}}
 */
#include "skg{{cookiecutter.__plugin_slug}}pluginwidget.h"

#include <qdom.h>

#include "skgmainpanel.h"
#include "skgtraces.h"
#include "skgdocument.h"

SKG{{cookiecutter.__plugin_slug}}PluginWidget::SKG{{cookiecutter.__plugin_slug}}PluginWidget(QWidget* iParent, SKGDocument* iDocument)
    : SKGTabPage(iParent, iDocument)
{
    SKGTRACEINFUNC(1)
    if (!iDocument) {
        return;
    }

    ui.setupUi(this);

    // Build you panel here
}

SKG{{cookiecutter.__plugin_slug}}PluginWidget::~SKG{{cookiecutter.__plugin_slug}}PluginWidget()
{
    SKGTRACEINFUNC(1)
}

QString SKG{{cookiecutter.__plugin_slug}}PluginWidget::getState()
{
    SKGTRACEINFUNC(10)
    QDomDocument doc("SKGML");
    QDomElement root = doc.createElement("parameters");
    doc.appendChild(root);

    // Get state
    // Example: QString account=root.attribute ( "account");
    //         if (account.isEmpty()) root.setAttribute(QStringLiteral("account"), ui.kDisplayAccountCombo->currentText());

    return doc.toString();
}

void SKG{{cookiecutter.__plugin_slug}}PluginWidget::setState(const QString& iState)
{
    SKGTRACEINFUNC(10)
    QDomDocument doc("SKGML");
    doc.setContent(iState);
    QDomElement root = doc.documentElement();

    // Set state
    // Example: QString account=root.attribute ( "account");
}

QString SKG{{cookiecutter.__plugin_slug}}PluginWidget::getDefaultStateAttribute()
{
    return "";
}

QWidget* SKG{{cookiecutter.__plugin_slug}}PluginWidget::mainWidget()
{
    return this;
}

void SKG{{cookiecutter.__plugin_slug}}PluginWidget::refresh()

{
    SKGTRACEINFUNC(1)

    QSqlDatabase* db = getDocument()->getDatabase();
    setEnabled(db != nullptr);
    if (db != nullptr) {
        // Refresh yours widgets here
    }
}




